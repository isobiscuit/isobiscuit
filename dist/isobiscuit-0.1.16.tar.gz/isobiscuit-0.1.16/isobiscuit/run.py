import sys
from runner import run



biscuit = sys.argv[1]
run(biscuit)